
const Preloader = () => {
  return (
    <div className="st-preloader">
      <div className="st-preloader-in"></div>
    </div>
  );
};

export default Preloader;